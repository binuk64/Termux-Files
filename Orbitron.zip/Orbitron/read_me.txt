  
               Orbitron 3.71
  *satellite tracking system for everyone*

      (C) 2001-2005 by Sebastian Stoff

============================================
  www.stoff.pl          sebastian@stoff.pl
============================================

System requirements (recommendations):
  - Windows 9x/2k/Me/XP/2003
  - 150 MHz processor (300 MHz)
  - 16 MB RAM (32 MB)
  - 5 MB HDD
  - 640x480 screen resolution (800x600x16)

--------------------------------------------

  Additional information can be found in: 
               HELP\INDEX.HTM

============================================
 With any problems feel free to contact me!
